
const menuBtn=document.getElementById('menuBtn'), navLinks=document.getElementById('navLinks');
if(menuBtn) menuBtn.onclick=()=>navLinks.classList.toggle('show');
let size=100;
document.getElementById('contrastBtn')?.addEventListener('click',()=>document.body.classList.toggle('high-contrast'));
document.getElementById('fontIncrease')?.addEventListener('click',()=>{size=Math.min(140,size+10);document.documentElement.style.fontSize=size+'%'});
document.getElementById('fontReset')?.addEventListener('click',()=>{size=100;document.documentElement.style.fontSize='100%'});
document.getElementById('readPage')?.addEventListener('click',()=>{speechSynthesis.cancel();speechSynthesis.speak(new SpeechSynthesisUtterance(document.querySelector('main').innerText))});
document.getElementById('stopReading')?.addEventListener('click',()=>speechSynthesis.cancel());
